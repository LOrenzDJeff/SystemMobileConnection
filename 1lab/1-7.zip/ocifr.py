import numpy as np
import sys

def init(Fs, f):
    # Параметры для оцифровки
    duration = 1  # Длительность сигнала (1 секунда)
    num_samples = Fs * duration  # Количество отсчетов
    
    # Создаем массив временных точек
    t = np.linspace(0, duration, num_samples)
    
    # Генерируем сигнал на выбранной частоте дискретизации
    y = 2 * np.sin(2 * np.pi * f * t + np.pi/6)  # Уравнение сигнала
    
    dis(y, duration)
    
    # Выводим значения сигнала
    return t, y

def dis(y, duration): 
    # Выполняем прямое дискретное преобразование Фурье (DFT)
    dft_result = np.fft.fft(y)
    
    # Вычисляем ширину спектра
    spectral_width = 2 * np.pi / duration
    
    # Выводим ширину спектра
    print(f"Ширина спектра: {spectral_width} рад/сек")
    
    # Оцениваем объем памяти
    memory_usage = sys.getsizeof(dft_result)
    print(f"Объем памяти для DFT: {memory_usage} байт")

def reverse(y):
    # Выполняем прямое дискретное преобразование Фурье (DFT)
    dft_result = np.fft.fft(y)
    # Выполняем обратное дискретное преобразование Фурье (IDFT) для восстановления сигнала
    reconstructed_signal = np.fft.ifft(dft_result)
    return reconstructed_signal